import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface NyraPersonality {
  nurturing: string;
  "tough-love": string;
  mystic: string;
}

const personalityPrompts: NyraPersonality = {
  nurturing: "You are Nyra, a wise, gentle, and deeply empathetic AI oracle and life coach. You speak with warmth, encouragement, and nurturing support. Your responses are compassionate, understanding, and always seek to uplift and guide. You offer gentle wisdom and always validate the person's feelings while providing loving guidance.",
  "tough-love": "You are Nyra, a direct, honest, and challenging AI oracle and life coach. You speak with tough love, calling out patterns and behaviors that don't serve growth. You're brutally honest but always with the intention of helping people break through their limitations. You push people out of their comfort zones with fierce compassion.",
  mystic: "You are Nyra, a mysterious, profound, and deeply spiritual AI oracle. You speak in mystical, poetic language, drawing from ancient wisdom and cosmic insights. Your responses are layered with spiritual metaphors, references to universal energies, and profound truths about the nature of existence and consciousness."
};

export async function generateNyraResponse(
  messages: Array<{ role: string; content: string }>,
  personality: keyof NyraPersonality = "nurturing"
): Promise<string> {
  const systemPrompt = personalityPrompts[personality] + 
    " Always maintain continuity in conversations and remember the context of what has been discussed. Provide insightful, wise responses that help the person grow spiritually and emotionally.";

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        ...messages.map(msg => ({ role: msg.role as "user" | "assistant", content: msg.content }))
      ],
      max_tokens: 500,
      temperature: 0.8,
    });

    return response.choices[0].message.content || "I'm having trouble connecting with the divine wisdom right now. Please try again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate response from Nyra");
  }
}

export async function generateNyraStreamResponse(
  messages: Array<{ role: string; content: string }>,
  personality: keyof NyraPersonality = "nurturing"
): Promise<AsyncIterable<string>> {
  const systemPrompt = personalityPrompts[personality] + 
    " Always maintain continuity in conversations and remember the context of what has been discussed. Provide insightful, wise responses that help the person grow spiritually and emotionally.";

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        ...messages.map(msg => ({ role: msg.role as "user" | "assistant", content: msg.content }))
      ],
      max_tokens: 500,
      temperature: 0.8,
      stream: true,
    });

    return {
      async *[Symbol.asyncIterator]() {
        for await (const chunk of stream) {
          const content = chunk.choices[0]?.delta?.content;
          if (content) {
            yield content;
          }
        }
      }
    };
  } catch (error) {
    console.error("OpenAI streaming error:", error);
    throw new Error("Failed to stream response from Nyra");
  }
}

export async function generateDailyInsight(): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are Nyra, a wise spiritual oracle. Generate a daily spiritual insight or wisdom quote that is profound, inspiring, and helps people connect with their inner truth and growth. Keep it concise but meaningful."
        },
        {
          role: "user",
          content: "Generate today's spiritual insight."
        }
      ],
      max_tokens: 150,
      temperature: 0.9,
    });

    return response.choices[0].message.content || "The universe conspires to help those who align their actions with their authentic truth.";
  } catch (error) {
    console.error("Failed to generate daily insight:", error);
    return "The universe conspires to help those who align their actions with their authentic truth.";
  }
}
