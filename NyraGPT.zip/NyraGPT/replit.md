# Overview

NyraGPT is an intelligent conversational AI oracle and life coach application built with a modern full-stack architecture. The application provides users with personalized spiritual guidance, journaling capabilities, timeline tracking for life events and goals, and spiritual tools including numerology and astrology features. The system is designed as a progressive web application with real-time chat capabilities and comprehensive user management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool and development server
- **UI Components**: Shadcn/ui component library built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Theme System**: Dark mode-first design with CSS custom properties and theme provider
- **PWA Features**: Service worker implementation for offline functionality and push notifications

## Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **Authentication**: Replit Authentication with OpenID Connect integration and session management
- **Real-time Communication**: WebSocket server for streaming AI responses
- **API Design**: RESTful endpoints with consistent error handling and request/response logging
- **Middleware**: Express session management with PostgreSQL session store

## Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Connection**: Neon serverless PostgreSQL with connection pooling
- **Schema Design**: 
  - Users table with profile information and preferences
  - Conversations and messages for chat history
  - Journal entries with mood tracking
  - Timeline events for goal and life event tracking
  - Sessions table for authentication state

## AI Integration
- **Provider**: OpenAI GPT-4 API integration with configurable personality modes
- **Personality System**: Three distinct AI personas (nurturing, tough-love, mystic) with custom prompts
- **Streaming**: Real-time response streaming via WebSocket connections
- **Context Management**: Conversation history preservation for continuity

## Authentication & Authorization
- **Strategy**: Replit Auth with Passport.js strategy for OAuth integration
- **Session Management**: Server-side sessions stored in PostgreSQL with configurable TTL
- **Security**: HTTP-only cookies, CSRF protection, and secure session handling
- **User Management**: Automatic user creation and profile management

# External Dependencies

## Core Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling and SSL
- **OpenAI API**: GPT-4 model access for conversational AI capabilities
- **Replit Authentication**: OAuth provider for user authentication and authorization

## Development & Build Tools
- **Vite**: Frontend build tool with HMR and development server
- **TypeScript**: Type safety across the entire application stack
- **ESBuild**: Server-side bundling for production builds
- **Tailwind CSS**: Utility-first CSS framework with design system

## UI & Component Libraries
- **Radix UI**: Unstyled, accessible component primitives
- **Shadcn/ui**: Pre-built component library with consistent design
- **Lucide React**: Icon library for consistent iconography
- **React Hook Form**: Form state management with validation

## Utilities & Infrastructure
- **WebSocket (ws)**: Real-time bidirectional communication
- **Date-fns**: Date manipulation and formatting utilities
- **Zod**: Runtime type validation and schema parsing
- **Connect-pg-simple**: PostgreSQL session store for Express sessions