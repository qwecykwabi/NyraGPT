import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import ChatInterface from "@/components/chat/chat-interface";
import SpiritualTools from "@/components/spiritual/spiritual-tools";
import JournalInterface from "@/components/journal/journal-interface";
import TimelineInterface from "@/components/timeline/timeline-interface";
import SettingsInterface from "@/components/settings/settings-interface";
import BottomNavigation from "@/components/navigation/bottom-navigation";

type ViewType = "chat" | "spiritual" | "journal" | "timeline" | "settings";

export default function Home() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [currentView, setCurrentView] = useState<ViewType>("chat");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[var(--dark-primary)] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-[var(--glow-blue)] to-[var(--glow-purple)] flex items-center justify-center pulse-glow">
            <i className="fas fa-brain text-white text-2xl"></i>
          </div>
          <p className="text-gray-400">Connecting to the divine wisdom...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  const titles: Record<ViewType, string> = {
    chat: "AI Oracle",
    spiritual: "Spiritual Tools",
    journal: "Sacred Journal",
    timeline: "Life Timeline",
    settings: "Settings",
  };

  return (
    <div className="min-h-screen bg-[var(--dark-primary)] text-white flex flex-col">
      {/* Header */}
      <header className="bg-[var(--dark-secondary)] border-b border-gray-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[var(--glow-blue)] to-[var(--glow-purple)] flex items-center justify-center">
            <i className="fas fa-brain text-white text-lg"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gradient">NyraGPT</h1>
            <p className="text-xs text-gray-400">{titles[currentView]}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button className="p-2 rounded-full bg-[var(--dark-tertiary)] hover:bg-gray-700 transition-colors">
            <i className="fas fa-bell text-gray-400"></i>
          </button>
          <div className="w-8 h-8 rounded-full bg-gray-600 overflow-hidden">
            {(user as any)?.profileImageUrl ? (
              <img 
                src={(user as any).profileImageUrl} 
                alt="Profile" 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-r from-[var(--glow-purple)] to-[var(--glow-cyan)] flex items-center justify-center">
                <span className="text-white text-sm font-semibold">
                  {(user as any)?.firstName?.[0] || (user as any)?.email?.[0] || "U"}
                </span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        {currentView === "chat" && <ChatInterface />}
        {currentView === "spiritual" && <SpiritualTools />}
        {currentView === "journal" && <JournalInterface />}
        {currentView === "timeline" && <TimelineInterface />}
        {currentView === "settings" && <SettingsInterface />}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation currentView={currentView} onViewChange={setCurrentView} />
    </div>
  );
}
