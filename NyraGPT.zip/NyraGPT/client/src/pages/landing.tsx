import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Sparkles, BookOpen, Map, Settings } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--dark-primary)] via-[var(--dark-secondary)] to-[var(--dark-primary)] flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8">
        {/* Logo and Title */}
        <div className="text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-[var(--glow-blue)] to-[var(--glow-purple)] flex items-center justify-center shadow-glow-blue">
            <Brain className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gradient mb-2">NyraGPT</h1>
          <p className="text-gray-400 text-lg">Your AI Oracle & Life Coach</p>
        </div>

        {/* Features */}
        <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)]">
          <CardHeader>
            <CardTitle className="text-center text-white">Discover Your Path</CardTitle>
            <CardDescription className="text-center text-gray-400">
              An intelligent companion for spiritual growth and personal transformation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[var(--glow-blue)] to-[var(--glow-purple)] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-gray-300">AI-powered conversations with Nyra</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[var(--glow-purple)] to-[var(--glow-cyan)] flex items-center justify-center">
                <BookOpen className="w-4 h-4 text-white" />
              </div>
              <span className="text-gray-300">Sacred journaling with mood tracking</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[var(--glow-cyan)] to-[var(--glow-blue)] flex items-center justify-center">
                <Map className="w-4 h-4 text-white" />
              </div>
              <span className="text-gray-300">Timeline for life events & goals</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[var(--glow-blue)] to-[var(--glow-purple)] flex items-center justify-center">
                <Settings className="w-4 h-4 text-white" />
              </div>
              <span className="text-gray-300">Spiritual tools & daily insights</span>
            </div>
          </CardContent>
        </Card>

        {/* Sign In Button */}
        <Button 
          className="floating-action w-full py-6 text-lg font-semibold hover:shadow-glow-purple transition-all"
          onClick={() => window.location.href = "/api/login"}
        >
          Begin Your Journey
        </Button>

        <p className="text-center text-gray-500 text-sm">
          Connect with your inner wisdom and unlock your potential
        </p>
      </div>
    </div>
  );
}
