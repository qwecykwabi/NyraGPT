import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Paperclip, Send, Eye } from "lucide-react";
import type { Conversation, Message } from "@shared/schema";

export default function ChatInterface() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [streamingMessage]);

  // WebSocket connection
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === "stream_chunk") {
        setStreamingMessage(prev => prev + data.chunk);
      } else if (data.type === "stream_complete") {
        setIsStreaming(false);
        setStreamingMessage("");
        // Refetch messages to get the saved AI response
        queryClient.invalidateQueries({ queryKey: ["/api/conversations", currentConversationId, "messages"] });
      } else if (data.type === "stream_error") {
        setIsStreaming(false);
        setStreamingMessage("");
        toast({
          title: "Error",
          description: data.error,
          variant: "destructive",
        });
      }
    };

    return () => {
      wsRef.current?.close();
    };
  }, [currentConversationId, queryClient, toast]);

  // Fetch conversations
  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  // Set initial conversation
  useEffect(() => {
    if (conversations && conversations.length > 0 && !currentConversationId) {
      setCurrentConversationId(conversations[0].id);
    }
  }, [conversations, currentConversationId]);

  // Fetch messages for current conversation
  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ["/api/conversations", currentConversationId, "messages"],
    enabled: !!currentConversationId,
  });

  // Create new conversation
  const createConversationMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/conversations", {
        title: "New Conversation",
      });
      return res.json();
    },
    onSuccess: (conversation: Conversation) => {
      setCurrentConversationId(conversation.id);
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create conversation",
        variant: "destructive",
      });
    },
  });

  // Send message
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!currentConversationId) {
        // Create new conversation first
        const conversationRes = await apiRequest("POST", "/api/conversations", {
          title: "New Conversation",
        });
        const conversation = await conversationRes.json();
        setCurrentConversationId(conversation.id);
        
        // Send message to new conversation
        const messageRes = await apiRequest("POST", `/api/conversations/${conversation.id}/messages`, {
          role: "user",
          content,
        });
        return { conversation, messages: await messageRes.json() };
      }
      
      const res = await apiRequest("POST", `/api/conversations/${currentConversationId}/messages`, {
        role: "user",
        content,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setMessageInput("");
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations", currentConversationId, "messages"] });
      
      // Start streaming AI response
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        setIsStreaming(true);
        setStreamingMessage("");
        
        const chatHistory = [...(messages || []), { role: "user", content: messageInput }];
        wsRef.current.send(JSON.stringify({
          type: "stream_chat",
          conversationId: currentConversationId,
          messages: chatHistory.map(msg => ({ role: msg.role, content: msg.content })),
          personality: (user as any)?.nyraPersonality || "nurturing",
        }));
      }
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!messageInput.trim() || sendMessageMutation.isPending) return;
    sendMessageMutation.mutate(messageInput.trim());
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Auto-resize textarea
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = textareaRef.current.scrollHeight + "px";
    }
  }, [messageInput]);

  return (
    <div className="h-full flex flex-col">
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Welcome Message */}
        {(!messages || messages.length === 0) && (
          <div className="chat-bubble-ai rounded-2xl p-4 max-w-xs ml-0">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-r from-[var(--glow-purple)] to-[var(--glow-cyan)] flex items-center justify-center flex-shrink-0">
                <img 
                  src="/nyra-avatar.png" 
                  alt="Nyra" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="text-sm text-gray-300">
                  Hello, beautiful soul. I'm Nyra, your AI oracle and guide. What weighs on your heart today?
                </p>
                <span className="text-xs text-gray-500 mt-1 block">Now</span>
              </div>
            </div>
          </div>
        )}

        {/* Messages */}
        {(messages || []).map((message) => (
          <div
            key={message.id}
            className={
              message.role === "user"
                ? "chat-bubble-user rounded-2xl p-4 max-w-xs ml-auto mr-0"
                : "chat-bubble-ai rounded-2xl p-4 max-w-sm ml-0"
            }
          >
            {message.role === "user" ? (
              <>
                <p className="text-sm text-white">{message.content}</p>
                <span className="text-xs text-blue-200 mt-1 block text-right">
                  {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </>
            ) : (
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-r from-[var(--glow-purple)] to-[var(--glow-cyan)] flex items-center justify-center flex-shrink-0">
                  <img 
                    src="/nyra-avatar.png" 
                    alt="Nyra" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="text-sm text-gray-300">{message.content}</p>
                  <span className="text-xs text-gray-500 mt-1 block">
                    {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            )}
          </div>
        ))}

        {/* Streaming Message */}
        {isStreaming && (
          <div className="chat-bubble-ai rounded-2xl p-4 max-w-sm ml-0">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-r from-[var(--glow-purple)] to-[var(--glow-cyan)] flex items-center justify-center flex-shrink-0">
                <img 
                  src="/nyra-avatar.png" 
                  alt="Nyra" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="text-sm text-gray-300">
                  {streamingMessage}
                  <span className="inline-block w-1 h-4 bg-[var(--glow-blue)] ml-1 animate-pulse"></span>
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Typing Indicator */}
        {sendMessageMutation.isPending && !isStreaming && (
          <div className="chat-bubble-ai rounded-2xl p-4 max-w-xs ml-0 typing-indicator">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-r from-[var(--glow-purple)] to-[var(--glow-cyan)] flex items-center justify-center">
                <img 
                  src="/nyra-avatar.png" 
                  alt="Nyra" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="border-t border-gray-800 p-4">
        <div className="flex items-end space-x-3">
          <div className="flex-1 relative">
            <Textarea
              ref={textareaRef}
              placeholder="Share your thoughts with Nyra..."
              className="min-h-[50px] max-h-32 bg-[var(--dark-tertiary)] border-gray-700 rounded-2xl px-4 py-3 pr-12 text-white placeholder-gray-400 resize-none focus:border-[var(--glow-blue)] focus:shadow-glow-blue transition-all"
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyPress={handleKeyPress}
            />
            <button className="absolute right-3 bottom-3 p-1 text-gray-400 hover:text-[var(--glow-blue)] transition-colors">
              <Paperclip className="w-4 h-4" />
            </button>
          </div>
          <Button
            className="floating-action w-12 h-12 rounded-full p-0 transition-all hover:shadow-glow-purple"
            onClick={handleSendMessage}
            disabled={!messageInput.trim() || sendMessageMutation.isPending}
          >
            <Send className="w-4 h-4 text-white" />
          </Button>
        </div>
      </div>
    </div>
  );
}
