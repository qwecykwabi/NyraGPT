import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Save, Edit } from "lucide-react";
import type { JournalEntry } from "@shared/schema";

const moodEmojis = {
  joyful: "😊",
  calm: "😌", 
  stressed: "😰",
  contemplative: "🤔",
  grateful: "🙏",
};

type MoodType = keyof typeof moodEmojis;

export default function JournalInterface() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [journalContent, setJournalContent] = useState("");

  // Fetch journal entries
  const { data: entries = [], isLoading } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal"],
  });

  // Create journal entry
  const createEntryMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/journal", {
        content: journalContent,
        mood: selectedMood,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Entry Saved",
        description: "Your journal entry has been saved.",
      });
      setJournalContent("");
      setSelectedMood(null);
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save journal entry",
        variant: "destructive",
      });
    },
  });

  const handleSaveEntry = () => {
    if (!journalContent.trim()) {
      toast({
        title: "Empty Entry",
        description: "Please write something before saving.",
        variant: "destructive",
      });
      return;
    }
    createEntryMutation.mutate();
  };

  return (
    <div className="h-full overflow-y-auto p-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gradient mb-2">Sacred Journal</h2>
          <p className="text-gray-400">Reflect on your journey</p>
        </div>

        {/* New Entry Form */}
        <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)] mb-6">
          <CardHeader>
            <CardTitle className="text-white">Today's Reflection</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Mood Selector */}
            <div>
              <Label className="text-gray-300 mb-2">How are you feeling?</Label>
              <div className="flex space-x-3 mt-2">
                {(Object.keys(moodEmojis) as MoodType[]).map((mood) => (
                  <button
                    key={mood}
                    className={`w-12 h-12 rounded-full bg-[var(--dark-tertiary)] hover:shadow-glow-blue transition-all text-2xl ${
                      selectedMood === mood ? "ring-2 ring-[var(--glow-blue)]" : ""
                    }`}
                    onClick={() => setSelectedMood(mood)}
                  >
                    {moodEmojis[mood]}
                  </button>
                ))}
              </div>
            </div>

            {/* Journal Text Area */}
            <div>
              <Label className="text-gray-300 mb-2">Your thoughts...</Label>
              <Textarea
                placeholder="What insights emerged today? What are you learning about yourself?"
                className="h-32 bg-[var(--dark-primary)] border-gray-700 rounded-xl text-white placeholder-gray-400 resize-none focus:border-[var(--glow-blue)] focus:shadow-glow-blue transition-all mt-2"
                value={journalContent}
                onChange={(e) => setJournalContent(e.target.value)}
              />
            </div>

            <Button
              className="floating-action px-6 py-3 rounded-xl font-medium transition-all hover:shadow-glow-purple"
              onClick={handleSaveEntry}
              disabled={createEntryMutation.isPending}
            >
              <Save className="w-4 h-4 mr-2" />
              {createEntryMutation.isPending ? "Saving..." : "Save Entry"}
            </Button>
          </CardContent>
        </Card>

        {/* Previous Entries */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg text-gray-300">Recent Entries</h3>
          
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-2 border-[var(--glow-blue)] border-t-transparent rounded-full mx-auto"></div>
              <p className="text-gray-400 mt-2">Loading your reflections...</p>
            </div>
          ) : (!entries || entries.length === 0) ? (
            <Card className="bg-[var(--dark-secondary)] border-gray-800">
              <CardContent className="text-center py-8">
                <p className="text-gray-400">No journal entries yet. Start reflecting!</p>
              </CardContent>
            </Card>
          ) : (
            entries.map((entry) => (
              <Card key={entry.id} className="bg-[var(--dark-secondary)] border-gray-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {entry.mood && (
                        <span className="text-2xl">{moodEmojis[entry.mood as MoodType]}</span>
                      )}
                      <span className="text-sm text-gray-400">
                        {new Date(entry.createdAt).toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <button className="text-gray-400 hover:text-white transition-colors">
                      <Edit className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-gray-300 text-sm">{entry.content}</p>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
