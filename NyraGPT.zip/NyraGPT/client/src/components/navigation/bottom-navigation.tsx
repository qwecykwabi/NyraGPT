import { MessageCircle, Sparkles, BookOpen, Map, Settings } from "lucide-react";

type ViewType = "chat" | "spiritual" | "journal" | "timeline" | "settings";

interface BottomNavigationProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
}

export default function BottomNavigation({ currentView, onViewChange }: BottomNavigationProps) {
  const navItems = [
    { id: "chat" as ViewType, icon: MessageCircle, label: "Chat" },
    { id: "spiritual" as ViewType, icon: Sparkles, label: "Tools" },
    { id: "journal" as ViewType, icon: BookOpen, label: "Journal" },
    { id: "timeline" as ViewType, icon: Map, label: "Timeline" },
    { id: "settings" as ViewType, icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="bg-[var(--dark-secondary)] border-t border-gray-800 px-4 py-2">
      <div className="flex justify-around">
        {navItems.map(({ id, icon: Icon, label }) => (
          <button
            key={id}
            className={`flex flex-col items-center py-2 px-3 rounded-xl transition-all ${
              currentView === id
                ? "nav-active text-white"
                : "text-gray-400 hover:text-white"
            }`}
            onClick={() => onViewChange(id)}
          >
            <Icon className="text-lg mb-1" size={20} />
            <span className="text-xs">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
