import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calculator, Star, Sun } from "lucide-react";

export default function SpiritualTools() {
  const { toast } = useToast();

  // Fetch daily insight
  const { data: dailyInsight } = useQuery<{ insight: string }>({
    queryKey: ["/api/daily-insight"],
  });

  return (
    <div className="h-full overflow-y-auto p-4 space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gradient mb-2">Spiritual Tools</h2>
        <p className="text-gray-400">Discover insights about your path</p>
      </div>

      {/* Tool Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Numerology Card */}
        <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)] hover:shadow-glow-blue transition-all cursor-pointer">
          <CardHeader>
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[var(--glow-blue)] to-[var(--glow-purple)] flex items-center justify-center">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">Numerology</CardTitle>
                <CardDescription>Life path insights</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 text-sm">
              Discover your life path number and what it reveals about your soul's journey.
            </p>
          </CardContent>
        </Card>

        {/* Astrology Card */}
        <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)] hover:shadow-glow-purple transition-all cursor-pointer">
          <CardHeader>
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[var(--glow-purple)] to-[var(--glow-cyan)] flex items-center justify-center">
                <Star className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">Birth Chart</CardTitle>
                <CardDescription>Cosmic blueprint</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 text-sm">
              Generate your natal chart and understand the celestial influences on your life.
            </p>
          </CardContent>
        </Card>

        {/* Daily Insight Card */}
        <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)] md:col-span-2">
          <CardHeader>
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[var(--glow-cyan)] to-[var(--glow-blue)] flex items-center justify-center">
                <Sun className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">Today's Spiritual Insight</CardTitle>
                <CardDescription>Daily wisdom</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-[var(--dark-primary)] rounded-xl p-4">
              <p className="text-gray-300 italic">
                {dailyInsight?.insight || "The universe conspires to help those who align their actions with their authentic truth. Today, listen to the whispers of your intuition—they carry messages from your highest self."}
              </p>
              <p className="text-[var(--glow-cyan)] text-sm mt-2">— Nyra's Daily Oracle</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
