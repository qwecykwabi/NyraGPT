import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Shield, LogOut } from "lucide-react";
import type { User } from "@shared/schema";

export default function SettingsInterface() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [apiKey, setApiKey] = useState("");

  // Update user settings
  const updateSettingsMutation = useMutation({
    mutationFn: async (settings: { 
      nyraPersonality?: string;
      dailyReminders?: boolean;
      spiritualInsights?: boolean;
    }) => {
      const res = await apiRequest("PATCH", "/api/user/settings", settings);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Settings Updated",
        description: "Your preferences have been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      });
    },
  });

  const handlePersonalityChange = (personality: string) => {
    updateSettingsMutation.mutate({ nyraPersonality: personality });
  };

  const handleToggle = (setting: "dailyReminders" | "spiritualInsights", value: boolean) => {
    updateSettingsMutation.mutate({ [setting]: value });
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className="h-full overflow-y-auto p-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gradient mb-2">Settings</h2>
          <p className="text-gray-400">Customize your experience</p>
        </div>

        <div className="space-y-6">
          {/* Nyra's Personality */}
          <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)]">
            <CardHeader>
              <CardTitle className="text-white">Nyra's Voice & Tone</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">Choose Nyra's personality</Label>
                <Select
                  value={user?.nyraPersonality || "nurturing"}
                  onValueChange={handlePersonalityChange}
                >
                  <SelectTrigger className="bg-[var(--dark-tertiary)] border-gray-700 text-white mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[var(--dark-secondary)] border-gray-700">
                    <SelectItem value="nurturing">
                      <div>
                        <div className="font-medium">Nurturing Guide</div>
                        <div className="text-sm text-gray-400">Gentle, supportive, and encouraging</div>
                      </div>
                    </SelectItem>
                    <SelectItem value="tough-love">
                      <div>
                        <div className="font-medium">Tough Love Mentor</div>
                        <div className="text-sm text-gray-400">Direct, challenging, and honest</div>
                      </div>
                    </SelectItem>
                    <SelectItem value="mystic">
                      <div>
                        <div className="font-medium">Mystic Oracle</div>
                        <div className="text-sm text-gray-400">Mysterious, profound, and spiritual</div>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* AI Configuration */}
          <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)]">
            <CardHeader>
              <CardTitle className="text-white">AI Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">OpenAI API Key</Label>
                <Input
                  type="password"
                  placeholder="Your API key is configured server-side"
                  className="bg-[var(--dark-tertiary)] border-gray-700 text-white placeholder-gray-400 mt-2"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  disabled
                />
                <p className="text-xs text-gray-500 mt-1">
                  API keys are managed securely on the server
                </p>
              </div>
              <div>
                <Label className="text-gray-300">Response Length</Label>
                <Select defaultValue="balanced">
                  <SelectTrigger className="bg-[var(--dark-tertiary)] border-gray-700 text-white mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[var(--dark-secondary)] border-gray-700">
                    <SelectItem value="concise">Concise</SelectItem>
                    <SelectItem value="balanced">Balanced</SelectItem>
                    <SelectItem value="detailed">Detailed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Preferences */}
          <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)]">
            <CardHeader>
              <CardTitle className="text-white">Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Dark Mode</Label>
                  <p className="text-sm text-gray-400">Always enabled for spiritual focus</p>
                </div>
                <Switch checked disabled />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Daily Reminders</Label>
                  <p className="text-sm text-gray-400">Gentle nudges for journaling</p>
                </div>
                <Switch 
                  checked={user?.dailyReminders ?? true}
                  onCheckedChange={(checked) => handleToggle("dailyReminders", checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Spiritual Insights</Label>
                  <p className="text-sm text-gray-400">Daily wisdom notifications</p>
                </div>
                <Switch 
                  checked={user?.spiritualInsights ?? true}
                  onCheckedChange={(checked) => handleToggle("spiritualInsights", checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Account */}
          <Card className="gradient-glow border-gray-800 bg-[var(--dark-secondary)]">
            <CardHeader>
              <CardTitle className="text-white">Account</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant="ghost"
                className="w-full justify-start p-3 rounded-xl bg-[var(--dark-tertiary)] hover:bg-gray-700 transition-colors text-white"
              >
                <Download className="w-4 h-4 mr-3 text-[var(--glow-blue)]" />
                Export Data
              </Button>
              
              <Button
                variant="ghost"
                className="w-full justify-start p-3 rounded-xl bg-[var(--dark-tertiary)] hover:bg-gray-700 transition-colors text-white"
              >
                <Shield className="w-4 h-4 mr-3 text-[var(--glow-purple)]" />
                Privacy Settings
              </Button>
              
              <Button
                variant="ghost"
                className="w-full justify-start p-3 rounded-xl bg-[var(--dark-tertiary)] hover:bg-red-900 transition-colors text-red-400"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-3" />
                Sign Out
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
