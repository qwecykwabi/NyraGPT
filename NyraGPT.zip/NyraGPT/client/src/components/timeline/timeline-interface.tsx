import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Target, Heart, List, Calendar } from "lucide-react";
import type { TimelineEvent } from "@shared/schema";

export default function TimelineInterface() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [viewMode, setViewMode] = useState<"list" | "calendar">("list");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    eventType: "goal" as "goal" | "event",
    status: "in_progress" as "completed" | "in_progress" | "planned",
    targetDate: "",
    progress: 0,
  });

  // Fetch timeline events
  const { data: events = [], isLoading } = useQuery<TimelineEvent[]>({
    queryKey: ["/api/timeline"],
  });

  // Create timeline event
  const createEventMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/timeline", {
        ...formData,
        targetDate: formData.targetDate ? new Date(formData.targetDate).toISOString() : null,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Event Added",
        description: "Your timeline event has been added.",
      });
      setFormData({
        title: "",
        description: "",
        eventType: "goal",
        status: "in_progress",
        targetDate: "",
        progress: 0,
      });
      setIsDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/timeline"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add timeline event",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      toast({
        title: "Missing Title",
        description: "Please enter a title for your event.",
        variant: "destructive",
      });
      return;
    }
    createEventMutation.mutate();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500";
      case "in_progress":
        return "bg-yellow-500";
      case "planned":
        return "bg-blue-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Completed";
      case "in_progress":
        return "In Progress";
      case "planned":
        return "Planned";
      default:
        return "Unknown";
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gradient mb-2">Life Timeline</h2>
          <p className="text-gray-400">Track your journey & dreams</p>
        </div>

        {/* Add Event Button */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="floating-action w-full py-4 rounded-xl font-medium mb-6 transition-all hover:shadow-glow-purple">
              <Plus className="w-4 h-4 mr-2" />
              Add Life Event or Goal
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[var(--dark-secondary)] border-gray-800 text-white">
            <DialogHeader>
              <DialogTitle>Add Timeline Event</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label className="text-gray-300">Title</Label>
                <Input
                  className="bg-[var(--dark-tertiary)] border-gray-700 text-white mt-1"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter event title"
                />
              </div>
              
              <div>
                <Label className="text-gray-300">Description</Label>
                <Textarea
                  className="bg-[var(--dark-tertiary)] border-gray-700 text-white mt-1"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe your event or goal"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Type</Label>
                  <Select
                    value={formData.eventType}
                    onValueChange={(value: "goal" | "event") => setFormData({ ...formData, eventType: value })}
                  >
                    <SelectTrigger className="bg-[var(--dark-tertiary)] border-gray-700 text-white mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-secondary)] border-gray-700">
                      <SelectItem value="goal">Goal</SelectItem>
                      <SelectItem value="event">Life Event</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-gray-300">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value: "completed" | "in_progress" | "planned") => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger className="bg-[var(--dark-tertiary)] border-gray-700 text-white mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-secondary)] border-gray-700">
                      <SelectItem value="planned">Planned</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-gray-300">Target Date (Optional)</Label>
                <Input
                  type="date"
                  className="bg-[var(--dark-tertiary)] border-gray-700 text-white mt-1"
                  value={formData.targetDate}
                  onChange={(e) => setFormData({ ...formData, targetDate: e.target.value })}
                />
              </div>

              {formData.eventType === "goal" && (
                <div>
                  <Label className="text-gray-300">Progress ({formData.progress}%)</Label>
                  <Input
                    type="range"
                    min="0"
                    max="100"
                    className="mt-1"
                    value={formData.progress}
                    onChange={(e) => setFormData({ ...formData, progress: parseInt(e.target.value) })}
                  />
                </div>
              )}

              <Button
                type="submit"
                className="floating-action w-full py-2 rounded-xl font-medium transition-all hover:shadow-glow-purple"
                disabled={createEventMutation.isPending}
              >
                {createEventMutation.isPending ? "Adding..." : "Add Event"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Timeline View Toggle */}
        <div className="flex bg-[var(--dark-secondary)] rounded-xl p-1 mb-6">
          <button
            className={`flex-1 py-2 rounded-lg font-medium transition-all ${
              viewMode === "list" ? "nav-active text-white" : "text-gray-400 hover:text-white"
            }`}
            onClick={() => setViewMode("list")}
          >
            <List className="w-4 h-4 mr-2 inline" />
            List View
          </button>
          <button
            className={`flex-1 py-2 rounded-lg font-medium transition-all ${
              viewMode === "calendar" ? "nav-active text-white" : "text-gray-400 hover:text-white"
            }`}
            onClick={() => setViewMode("calendar")}
          >
            <Calendar className="w-4 h-4 mr-2 inline" />
            Calendar
          </button>
        </div>

        {/* Timeline Events */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-2 border-[var(--glow-blue)] border-t-transparent rounded-full mx-auto"></div>
              <p className="text-gray-400 mt-2">Loading your timeline...</p>
            </div>
          ) : (!events || events.length === 0) ? (
            <Card className="bg-[var(--dark-secondary)] border-gray-800">
              <CardContent className="text-center py-8">
                <p className="text-gray-400">No timeline events yet. Start tracking your journey!</p>
              </CardContent>
            </Card>
          ) : (
            (events || []).map((event: TimelineEvent, index: number) => (
              <div key={event.id} className="relative">
                {/* Timeline line */}
                {index < events.length - 1 && (
                  <div className="absolute left-6 top-8 bottom-0 w-0.5 bg-gradient-to-b from-[var(--glow-blue)] to-transparent"></div>
                )}
                
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${
                    event.eventType === "goal" 
                      ? "from-[var(--glow-blue)] to-[var(--glow-purple)]" 
                      : "from-[var(--glow-purple)] to-[var(--glow-cyan)]"
                  } flex items-center justify-center flex-shrink-0 ${
                    event.status === "in_progress" ? "pulse-glow" : ""
                  }`}>
                    {event.eventType === "goal" ? (
                      <Target className="w-5 h-5 text-white" />
                    ) : (
                      <Heart className="w-5 h-5 text-white" />
                    )}
                  </div>
                  
                  <Card className={`flex-1 ${
                    event.status === "in_progress" 
                      ? "gradient-glow border-gray-800" 
                      : "bg-[var(--dark-secondary)] border-gray-800"
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <CardTitle className="text-white">{event.title}</CardTitle>
                        <span className={`text-xs text-white px-2 py-1 rounded-full ${getStatusColor(event.status)}`}>
                          {getStatusText(event.status)}
                        </span>
                      </div>
                      
                      {event.description && (
                        <p className="text-gray-300 text-sm mb-2">{event.description}</p>
                      )}
                      
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>
                          {event.targetDate 
                            ? `Target: ${new Date(event.targetDate).toLocaleDateString()}`
                            : `Created: ${new Date(event.createdAt).toLocaleDateString()}`
                          }
                        </span>
                        {event.eventType === "goal" && (
                          <span>Progress: {event.progress}%</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
